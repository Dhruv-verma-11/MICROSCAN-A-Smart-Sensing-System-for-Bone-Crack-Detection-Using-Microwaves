import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd

def read_s11_data(file_paths):
    s11_values = []
    frequencies = None
    for file_path in file_paths:
        try:
            df = pd.read_csv(file_path)
            df.columns = df.columns.str.strip()  # Remove whitespace from column names
            print(f"Reading data from {file_path}...")

            # Check if required columns exist
            if 'Frequency (GHz)' not in df.columns or 'S11 (dB)' not in df.columns:
                print(f"Error: Required columns not found in {file_path}")
                continue

            if frequencies is None:
                frequencies = df['Frequency (GHz)'].values
            s11 = df['S11 (dB)'].values
            s11_values.append(s11)
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
    return frequencies, np.array(s11_values)

def detect_fractures(s11_values, threshold=-30):
    fracture_indices = np.where(s11_values < threshold)[1]  # Detect fractures across all antennas
    return np.unique(fracture_indices)  # Unique indices where fractures are detected

def create_bone_structure(height=10, resolution=100):
    z = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    theta, z = np.meshgrid(theta, z)
    radius = 2  # Radius of the bone
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return x, y, z

def plot_3d_bone_with_fractures(x, y, z, fracture_indices, antenna_coords):
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot the bone structure
    ax.plot_surface(x, y, z, color='lightgray', alpha=0.7, rstride=5, cstride=5)
    
    # Plot the fracture points
    fracture_x = x[:, fracture_indices % x.shape[1]]
    fracture_y = y[:, fracture_indices % y.shape[1]]
    fracture_z = z[:, fracture_indices % z.shape[1]]
    ax.scatter(fracture_x.flatten(), fracture_y.flatten(), fracture_z.flatten(), color='red', s=50, label='Fracture Points')

    # Plot the antenna positions
    ax.scatter(antenna_coords[:, 0], antenna_coords[:, 1], 0, color='blue', s=100, label='Antennas')

    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_zlabel('Z-axis')
    ax.set_title('3D Bone Shape with Fracture Points and Antenna Positions')
    ax.legend()
    plt.show()

def create_antenna_positions(radius=5):
    angles = np.linspace(0, 2 * np.pi, 8, endpoint=False)
    x = radius * np.cos(angles)
    y = radius * np.sin(angles)
    z = np.zeros_like(x)  # Antennas are at the same height (z = 0)
    return np.vstack((x, y, z)).T

def visualize_fractures_in_3d(file_paths):
    frequencies, s11_values = read_s11_data(file_paths)
    
    # Check if S11 data was read correctly
    if s11_values.size == 0:
        print("No valid S11 data found.")
        return
    
    fracture_indices = detect_fractures(s11_values)
    x, y, z = create_bone_structure()
    antenna_coords = create_antenna_positions()
    plot_3d_bone_with_fractures(x, y, z, fracture_indices, antenna_coords)

# Replace with the paths to your .csv files for each of the 8 antennas
file_paths = [
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna1.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna2.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna3.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna4.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna5.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna6.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna7.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna8.csv'
]

visualize_fractures_in_3d(file_paths)
