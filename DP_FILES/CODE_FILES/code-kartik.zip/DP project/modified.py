import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd

def read_s11_data(file_paths):
    s11_values = []
    frequencies = None
    for file_path in file_paths:
        df = pd.read_csv(file_path)
        df.columns = df.columns.str.strip()  # Remove whitespace from column names
        
        # Print columns to verify column names
        print(f"Columns in {file_path}: {df.columns.tolist()}")
        
        # Find columns for Frequency and S11 values by partial match
        frequency_column = next((col for col in df.columns if "Frequency" in col), None)
        s11_column = next((col for col in df.columns if "S11" in col), None)
        
        if frequency_column is None or s11_column is None:
            print(f"Error: Required columns not found in {file_path}")
            continue
        
        # Extract data using the detected columns
        if frequencies is None:
            frequencies = df[frequency_column].values
        s11 = df[s11_column].values
        s11_values.append(s11)
    
    return frequencies, np.array(s11_values)

def detect_fractures(s11_values, threshold=-30):
    fracture_indices = np.where(s11_values < threshold)[1]
    return np.unique(fracture_indices)

def create_bone_structure(height=10, resolution=100, radius=2):
    z = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    theta, z = np.meshgrid(theta, z)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return x, y, z

def create_air_structure(height=10, resolution=100, bone_radius=2, air_gap=1):
    air_radius = bone_radius + air_gap
    z = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    theta, z = np.meshgrid(theta, z)
    x = air_radius * np.cos(theta)
    y = air_radius * np.sin(theta)
    return x, y, z

def plot_3d_bone_with_fractures(x, y, z, fracture_indices, antenna_coords, air_x, air_y, air_z):
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    ax.plot_surface(x, y, z, color='sandybrown', alpha=0.8, rstride=5, cstride=5)
    ax.plot_surface(air_x, air_y, air_z, color='lightblue', alpha=0.3, rstride=5, cstride=5)
    
    fracture_x = x[:, fracture_indices % x.shape[1]] + np.random.uniform(-0.2, 0.2, size=fracture_indices.size)
    fracture_y = y[:, fracture_indices % y.shape[1]] + np.random.uniform(-0.2, 0.2, size=fracture_indices.size)
    fracture_z = z[:, fracture_indices % z.shape[1]]
    ax.scatter(fracture_x.flatten(), fracture_y.flatten(), fracture_z.flatten(), color='red', s=50, label='Fracture Points')
    
    ax.scatter(antenna_coords[:, 0], antenna_coords[:, 1], 0, color='blue', s=100, label='Antennas')

    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_zlabel('Z-axis')
    ax.set_title('3D Bone Shape with Fractures, Air, and Antenna Positions')
    ax.legend()
    plt.show()

def create_antenna_positions(radius=5):
    angles = np.linspace(0, 2 * np.pi, 8, endpoint=False)
    x = radius * np.cos(angles)
    y = radius * np.sin(angles)
    z = np.zeros_like(x)
    return np.vstack((x, y, z)).T

def visualize_fractures_in_3d(file_paths):
    frequencies, s11_values = read_s11_data(file_paths)
    fracture_indices = detect_fractures(s11_values)
    bone_x, bone_y, bone_z = create_bone_structure()
    air_x, air_y, air_z = create_air_structure()
    antenna_coords = create_antenna_positions()
    plot_3d_bone_with_fractures(bone_x, bone_y, bone_z, fracture_indices, antenna_coords, air_x, air_y, air_z)

# Replace with the paths to your .csv files
file_paths = [
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna1.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna2.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna3.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna4.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna5.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna6.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna7.csv',
    'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\antenna8.csv'
]

visualize_fractures_in_3d(file_paths)
