import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import skrf as rf

def read_s2p(file_path):
    network = rf.Network(file_path)
    frequencies = network.f
    s11 = 20 * np.log10(np.abs(network.s[:, 0, 0]))  
    s12 = 20 * np.log10(np.abs(network.s[:, 0, 1]))
    s21 = 20 * np.log10(np.abs(network.s[:, 1, 0]))
    s22 = 20 * np.log10(np.abs(network.s[:, 1, 1]))
    return frequencies, s11, s12, s21, s22

def detect_fractures(s11, s12, s21, s22, threshold=-30):
    fracture_indices = np.where((s11 < threshold) | (s12 < threshold) | (s21 < threshold) | (s22 < threshold))[0]
    return fracture_indices

def find_cracks(fracture_indices, max_gap=5):
    cracks = []
    current_crack = [fracture_indices[0]]
    for idx in range(1, len(fracture_indices)):
        if fracture_indices[idx] - fracture_indices[idx - 1] <= max_gap:
            current_crack.append(fracture_indices[idx])
        else:
            cracks.append(current_crack)
            current_crack = [fracture_indices[idx]]
    cracks.append(current_crack)
    return cracks

def create_random_bone_structure(height=10, resolution=100):
    z = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    theta, z = np.meshgrid(theta, z)
    radius = 1 + 4 * np.sin(2 * np.pi * z / height) + 0.5 * np.random.uniform(-1, 1, size=z.shape)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return x, y, z

def plot_3d_bone_with_fractures(x, y, z, cracks):
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_surface(x, y, z, color='lightgray', alpha=0.7, rstride=5, cstride=5)
    
    colors = plt.cm.rainbow(np.linspace(0, 1, len(cracks)))
    for i, crack in enumerate(cracks):
        fracture_x = x[np.array(crack) % x.shape[0], :]
        fracture_y = y[np.array(crack) % y.shape[0], :]
        fracture_z = z[np.array(crack) % z.shape[0], :]
        
        ax.plot(fracture_x.flatten(), fracture_y.flatten(), fracture_z.flatten(), 
                color=colors[i], linewidth=2, label=f'Crack {i+1}')

    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_zlabel('Z-axis')
    ax.set_title('3D Random Bone Shape with Cracks')
    ax.legend()
    plt.show()

def visualize_fractures_in_3d(file_path):
    frequencies, s11, s12, s21, s22 = read_s2p(file_path)
    fracture_indices = detect_fractures(s11, s12, s21, s22, threshold=-20) 
    cracks = find_cracks(fracture_indices, max_gap=3) 
    x, y, z = create_random_bone_structure()
    plot_3d_bone_with_fractures(x, y, z, cracks)

file_path = 'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\with_crack_0_deg.s2p' 
visualize_fractures_in_3d(file_path)
