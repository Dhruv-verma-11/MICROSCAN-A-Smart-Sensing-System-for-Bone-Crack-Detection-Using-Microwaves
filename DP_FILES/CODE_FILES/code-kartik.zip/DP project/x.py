import numpy as np
import matplotlib.pyplot as plt
import cv2
from mpl_toolkits.mplot3d import Axes3D
import skrf as rf

def create_random_bone_structure(height=10, resolution=100):
    z = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    theta, z = np.meshgrid(theta, z)
    
    radius = 1 + 4 * np.sin(2 * np.pi * z / height) + 0.5 * np.random.uniform(-1, 1, size=z.shape)
    
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return x, y, z

def plot_and_save_3d_bone(x, y, z, fracture_indices, image_path='bone_plot.png'):
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')

    ax.plot_surface(x, y, z, color='lightgray', alpha=0.8, rstride=5, cstride=5)

    fracture_z = np.linspace(z.min(), z.max(), z.shape[0])
    fracture_x = x[fracture_indices % x.shape[0], 0]
    fracture_y = y[fracture_indices % y.shape[0], 0]
    fracture_z = fracture_z[fracture_indices % z.shape[0]]

    ax.scatter(fracture_x, fracture_y, fracture_z, color='red', s=100, edgecolor='black', label='Fracture Points')

    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_zlabel('Z-axis')
    ax.set_title('3D Random Bone Shape with Fracture Points')
    ax.legend()

    plt.savefig(image_path, bbox_inches='tight')
    plt.close()

def display_image_with_opencv(image_path='bone_plot.png'):
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    cv2.imshow('3D Bone Plot', img_rgb)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def read_s2p_file(file_path):
    network = rf.Network(file_path)
    s_parameters = network.s
    magnitude_s11 = np.abs(s_parameters[0, 0, :])
    fracture_indices = np.argsort(magnitude_s11)[-10:]
    return fracture_indices

def visualize_3d_with_opencv(s2p_file_path):
    x, y, z = create_random_bone_structure()
    fracture_indices = read_s2p_file(s2p_file_path)
    plot_and_save_3d_bone(x, y, z, fracture_indices)
    display_image_with_opencv()

s2p_file_path = 'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\with_crack_0_deg.s2p'
visualize_3d_with_opencv(s2p_file_path)
