import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import skrf as rf

# Step 1: Read the .s2p file
def read_s2p(file_path):
    network = rf.Network(file_path)
    frequencies = network.f
    s11 = 20 * np.log10(np.abs(network.s[:, 0, 0]))  # Convert to dB
    s12 = 20 * np.log10(np.abs(network.s[:, 0, 1]))
    s21 = 20 * np.log10(np.abs(network.s[:, 1, 0]))
    s22 = 20 * np.log10(np.abs(network.s[:, 1, 1]))
    return frequencies, s11, s12, s21, s22

# Step 2: Detect fractures
def detect_fractures(s11, s12, s21, s22, threshold=-30):
    fracture_indices = np.where((s11 < threshold) | (s12 < threshold) | (s21 < threshold) | (s22 < threshold))[0]
    return fracture_indices

# Step 3: Create a random bone shape
def create_random_bone_structure(height=10, resolution=100):
    z = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    theta, z = np.meshgrid(theta, z)
    
    # Vary radius randomly along the height
    radius = 1 + 4 * np.sin(2 * np.pi * z / height) + 0.5 * np.random.uniform(-1, 1, size=z.shape)
    
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return x, y, z

# Step 4: Plot the 3D bone structure and mark fractures
def plot_3d_bone_with_fractures(x, y, z, fracture_indices):
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')

    # Plot the random bone structure
    ax.plot_surface(x, y, z, color='lightgray', alpha=0.7, rstride=5, cstride=5)

    # Map fractures to positions along the z-axis
    fracture_z = np.linspace(z.min(), z.max(), z.shape[0])
    fracture_x = x[fracture_indices % x.shape[0], 0]
    fracture_y = y[fracture_indices % y.shape[0], 0]
    fracture_z = fracture_z[fracture_indices % z.shape[0]]

    # Plot fracture points in red
    ax.scatter(fracture_x, fracture_y, fracture_z, color='red', s=50, label='Fracture Points')

    # Label axes
    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_zlabel('Z-axis')
    ax.set_title('3D Random Bone Shape with Fracture Points')
    ax.legend()

    plt.show()

# Main function to integrate everything
def visualize_fractures_in_3d(file_path):
    # Read S-parameters from the file
    frequencies, s11, s12, s21, s22 = read_s2p(file_path)

    # Detect fracture points
    fracture_indices = detect_fractures(s11, s12, s21, s22)

    # Create a random bone shape
    x, y, z = create_random_bone_structure()

    # Plot the bone with fracture points
    plot_3d_bone_with_fractures(x, y, z, fracture_indices)

# Usage
file_path = 'C:\\Users\\hp\\OneDrive\\Desktop\\DP project\\with_crack_0_deg.s2p'  # Replace with the path to your .s2p file
visualize_fractures_in_3d(file_path)
